const fs = require('fs');
console.log(new Date());
const data = fs.readFileSync('./textfile/data.txt');
console.log(data.toString());

/*fs.readFile('./textfile/data.txt', (err, data) => {
    console.log("***********************");
    console.log(data.toString());
});*/

console.log(new Date());