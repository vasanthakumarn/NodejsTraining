var fs =  require('fs');

var readStream = fs.createReadStream('./../textfile/data.txt');
var writeStream = fs.createWriteStream('./pipedtext.txt');

readStream.pipe(writeStream);