module.exports = {
    data: [
        { id: 1, title: 'Post 1', descriptions: 'First Post' },
        { id: 2, title: 'Post 2', descriptions: 'Second Post' },
        { id: 3, title: 'Post 3', descriptions: 'Third Post' },
        { id: 4, title: 'Post 4', descriptions: 'Fourth Post' },
    ] 
};